# TO-D0-LIST
A tech-centric TO-DO List with cloud sync, priority tagging, and automation. Integrates with GitHub, Jira, and Notion for seamless workflow management. Supports reminders, collaboration, and AI-powered task suggestions. 
